
import { useEffect, useRef, useState } from "react";
import { NavLink, useNavigate } from "react-router-dom";
import {
  LayoutDashboard,
  ClipboardList,
  Briefcase,
  Bell,
  User,
  LogOut,
  Menu,
  X,
  ChevronRight,
  Check,
  CheckCheck,
  RefreshCw,
  ExternalLink,
  ChevronDown,
  CircleUserRound,
  Settings,
} from "lucide-react";
import { useAuth } from "../context/AuthContext";
import api from "../services/api";
import PlatformAnnouncement from "../components/PlatformAnnouncement";
import AIAssistantWidget from "../components/AIAssistantWidget";

const menuItems = [
  {
    label: "Dashboard",
    path: "/customer/dashboard",
    icon: LayoutDashboard,
  },
  {
    label: "My Requests",
    path: "/customer/service-requests",
    icon: ClipboardList,
  },
  {
    label: "My Work Orders",
    path: "/customer/work-orders",
    icon: Briefcase,
  },
  {
    label: "Notifications",
    path: "/customer/notifications",
    icon: Bell,
  },
  {
    label: "Profile",
    path: "/customer/profile",
    icon: User,
  },
  {
    label: "Help & Support",
    path: "/customer/support",
    icon: ExternalLink,
  },
];

const CustomerLayout = ({ children }) => {
  const { user, logout, platformSettings } = useAuth();
  const navigate = useNavigate();

  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const profileMenuRef = useRef(null);
  const [notifications, setNotifications] = useState([]);
  const [notificationOpen, setNotificationOpen] = useState(false);
  const [notificationLoading, setNotificationLoading] = useState(false);
  const [wsConnected, setWsConnected] = useState(false);

  const unreadCount = Array.isArray(notifications)
    ? notifications.filter((notification) => !notification.is_read).length
    : 0;

  /*
   * LOAD EXISTING NOTIFICATIONS
   */
  const loadNotifications = async () => {
    try {
      setNotificationLoading(true);

      const response = await api.get("/notifications/");
      const data = response.data;

      if (Array.isArray(data)) {
        setNotifications(data);
      } else if (Array.isArray(data?.results)) {
        setNotifications(data.results);
      } else {
        console.error("Unexpected notifications response:", data);
        setNotifications([]);
      }
    } catch (error) {
      console.error("Failed to load customer notifications:", error);
    } finally {
      setNotificationLoading(false);
    }
  };

  // Close profile dropdown when clicking outside.
  useEffect(() => {
    const handleProfileClickOutside = (event) => {
      if (profileMenuRef.current && !profileMenuRef.current.contains(event.target)) {
        setProfileMenuOpen(false);
      }
    };
    document.addEventListener("mousedown", handleProfileClickOutside);
    return () => document.removeEventListener("mousedown", handleProfileClickOutside);
  }, []);

  /*
   * WEBSOCKET CONNECTION
   */
  useEffect(() => {
    let socket = null;
    let reconnectTimer = null;
    let stopped = false;

    const connectWebSocket = async () => {
      try {
        // Get a temporary WebSocket ticket from Django.
        const tokenResponse = await api.post("/auth/ws-ticket/");
        const ticket = tokenResponse.data?.ticket;

        if (!ticket || stopped) {
          return;
        }

        // Use the configured API backend host.
        // Production: https://seiyalam.onrender.com/api
        // Local:      http://127.0.0.1:8000/api
        const apiBaseUrl =
          api.defaults.baseURL || "http://127.0.0.1:8000/api";

        const parsedUrl = new URL(apiBaseUrl);
        const protocol =
          parsedUrl.protocol === "https:" ? "wss:" : "ws:";

        const wsUrl =
          `${protocol}//${parsedUrl.host}` +
          `/ws/notifications/?ticket=${encodeURIComponent(ticket)}`;

        console.log("Connecting customer WebSocket:", `${protocol}//${parsedUrl.host}/ws/notifications/`);

        const currentSocket = new WebSocket(wsUrl);
        socket = currentSocket;

        currentSocket.onopen = () => {
          if (stopped) {
            currentSocket.close();
            return;
          }

          console.log("Customer notification WebSocket connected.");
          setWsConnected(true);
        };

        currentSocket.onmessage = (event) => {
          try {
            const notification = JSON.parse(event.data);

            setNotifications((previous) => {
              const current = Array.isArray(previous) ? previous : [];

              const exists = current.some(
                (item) => item.id === notification.id
              );

              if (exists) {
                return current;
              }

              return [notification, ...current];
            });
          } catch (error) {
            console.error("Invalid notification WebSocket message:", error);
          }
        };

        currentSocket.onerror = (error) => {
          console.error("Customer notification WebSocket error:", error);
        };

        currentSocket.onclose = () => {
          if (socket === currentSocket) {
            socket = null;
          }

          setWsConnected(false);

          if (!stopped) {
            reconnectTimer = setTimeout(() => {
              connectWebSocket();
            }, 5000);
          }
        };
      } catch (error) {
        if (stopped) {
          return;
        }

        console.error("Failed to connect customer WebSocket:", error);
        setWsConnected(false);

        reconnectTimer = setTimeout(() => {
          connectWebSocket();
        }, 5000);
      }
    };

    loadNotifications();
    connectWebSocket();

    return () => {
      stopped = true;

      if (reconnectTimer) {
        clearTimeout(reconnectTimer);
      }

      if (socket) {
        // Prevent cleanup from triggering a new reconnect.
        socket.onclose = null;
        socket.close();
        socket = null;
      }

      setWsConnected(false);
    };
  }, []);

  /*
   * MARK ONE NOTIFICATION AS READ
   */
  const markAsRead = async (notificationId) => {
    try {
      const response = await api.post(
        `/notifications/${notificationId}/read/`
      );

      const updatedNotification = response.data;

      setNotifications((previous) => {
        const current = Array.isArray(previous) ? previous : [];

        return current.map((notification) =>
          notification.id === notificationId
            ? updatedNotification
            : notification
        );
      });
    } catch (error) {
      console.error("Failed to mark notification as read:", error);
    }
  };

  /*
   * MARK ALL NOTIFICATIONS AS READ
   */
  const markAllAsRead = async () => {
    const unreadNotifications = notifications.filter(
      (notification) => !notification.is_read
    );

    if (unreadNotifications.length === 0) {
      return;
    }

    try {
      await Promise.all(
        unreadNotifications.map((notification) =>
          api.post(`/notifications/${notification.id}/read/`)
        )
      );

      setNotifications((previous) =>
        (Array.isArray(previous) ? previous : []).map((notification) => ({
          ...notification,
          is_read: true,
        }))
      );
    } catch (error) {
      console.error("Failed to mark all notifications as read:", error);
      await loadNotifications();
    }
  };

  /*
   * LOGOUT
   */
  const handleLogout = () => {
    logout();
    navigate("/login");
  };

  /*
   * FORMAT NOTIFICATION TIME
   */
  const formatNotificationTime = (createdAt) => {
    if (!createdAt) {
      return "";
    }

    const date = new Date(createdAt);

    if (Number.isNaN(date.getTime())) {
      return "";
    }

    return date.toLocaleString();
  };

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 z-50 flex h-screen w-64 flex-col bg-slate-950 text-white transition-transform duration-300 ${
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0`}
      >
        {/* Logo */}
        <div className="flex h-16 items-center justify-between border-b border-slate-800 px-5">
          <div>
            <h1 className="text-xl font-bold tracking-wide">
              {platformSettings?.platform?.name || "SEIYALAM"}
            </h1>
            <p className="text-xs text-slate-400">Customer Portal</p>
          </div>

          <button
            onClick={() => setSidebarOpen(false)}
            className="rounded-lg p-2 hover:bg-slate-800 lg:hidden"
          >
            <X size={20} />
          </button>
        </div>

        {/* Navigation */}
        <nav className="flex-1 space-y-1 p-4">
          {menuItems.map((item) => {
            const Icon = item.icon;

            return (
              <NavLink
                key={item.path}
                to={item.path}
                onClick={() => setSidebarOpen(false)}
                className={({ isActive }) =>
                  `flex items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium transition ${
                    isActive
                      ? "bg-blue-600 text-white"
                      : "text-slate-300 hover:bg-slate-800 hover:text-white"
                  }`
                }
              >
                <Icon size={19} />
                <span>{item.label}</span>

                {item.label === "Notifications" && unreadCount > 0 && (
                  <span className="ml-auto flex min-w-[22px] items-center justify-center rounded-full bg-red-500 px-1.5 py-0.5 text-[11px] font-bold text-white">
                    {unreadCount > 99 ? "99+" : unreadCount}
                  </span>
                )}
              </NavLink>
            );
          })}
        </nav>

        {/* User section */}
        <div className="border-t border-slate-800 p-4">
          <div className="mb-3 rounded-lg bg-slate-900 p-3">
            <p className="truncate text-sm font-semibold">
              {user?.username || "Customer"}
            </p>
            <p className="mt-1 truncate text-xs text-slate-400">
              {user?.email || "Customer account"}
            </p>
          </div>

          <button
            onClick={handleLogout}
            className="flex w-full items-center gap-3 rounded-lg px-4 py-3 text-sm font-medium text-red-400 transition hover:bg-red-500/10 hover:text-red-300"
          >
            <LogOut size={19} />
            Logout
          </button>
        </div>
      </aside>

      {/* Main */}
      <div className="lg:ml-64">
        {/* Top navbar */}
        <header className="sticky top-0 z-30 flex h-16 items-center justify-between border-b border-slate-200 bg-white px-4 shadow-sm sm:px-6">
          <button
            onClick={() => setSidebarOpen(true)}
            className="rounded-lg p-2 text-slate-600 hover:bg-slate-100 lg:hidden"
          >
            <Menu size={22} />
          </button>

          <div className="ml-auto flex items-center gap-3">
            {/* Notification button */}
            <div className="relative">
              <button
                onClick={() => setNotificationOpen((previous) => !previous)}
                className="relative rounded-lg p-2.5 text-slate-600 transition hover:bg-slate-100"
                title="Notifications"
              >
                <Bell size={21} />

                {unreadCount > 0 && (
                  <span className="absolute -right-0.5 -top-0.5 flex min-w-[18px] items-center justify-center rounded-full bg-red-500 px-1 text-[10px] font-bold text-white">
                    {unreadCount > 99 ? "99+" : unreadCount}
                  </span>
                )}
              </button>

              {/* Notification dropdown */}
              {notificationOpen && (
                <div className="fixed left-4 right-4 top-16 z-50 mt-2 overflow-hidden rounded-xl border border-slate-200 bg-white shadow-xl sm:absolute sm:left-auto sm:right-0 sm:top-auto sm:w-[380px]">
                  {/* Header */}
                  <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
                    <div>
                      <h3 className="text-sm font-bold text-slate-800">
                        Notifications
                      </h3>
                      <p className="text-xs text-slate-500">
                        {unreadCount} unread
                      </p>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={loadNotifications}
                        disabled={notificationLoading}
                        className="rounded-lg p-2 text-slate-500 hover:bg-slate-100 disabled:opacity-50"
                        title="Refresh"
                      >
                        <RefreshCw
                          size={16}
                          className={notificationLoading ? "animate-spin" : ""}
                        />
                      </button>

                      {unreadCount > 0 && (
                        <button
                          onClick={markAllAsRead}
                          className="rounded-lg p-2 text-slate-500 hover:bg-slate-100"
                          title="Mark all as read"
                        >
                          <CheckCheck size={17} />
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Notification list */}
                  <div className="max-h-[420px] overflow-y-auto">
                    {notificationLoading && notifications.length === 0 && (
                      <div className="px-4 py-8 text-center text-sm text-slate-500">
                        Loading notifications...
                      </div>
                    )}

                    {!notificationLoading && notifications.length === 0 && (
                      <div className="px-4 py-10 text-center">
                        <Bell
                          size={28}
                          className="mx-auto mb-2 text-slate-300"
                        />
                        <p className="text-sm font-medium text-slate-600">
                          No notifications
                        </p>
                        <p className="mt-1 text-xs text-slate-400">
                          You are all caught up.
                        </p>
                      </div>
                    )}

                    {notifications.map((notification) => (
                      <div
                        key={notification.id}
                        className={`border-b border-slate-100 px-4 py-3 transition hover:bg-slate-50 ${
                          !notification.is_read ? "bg-blue-50/60" : "bg-white"
                        }`}
                      >
                        <div className="flex gap-3">
                          <div
                            className={`mt-0.5 flex h-9 w-9 shrink-0 items-center justify-center rounded-full ${
                              notification.is_read
                                ? "bg-slate-100 text-slate-500"
                                : "bg-blue-100 text-blue-600"
                            }`}
                          >
                            <Bell size={17} />
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-start justify-between gap-2">
                              <p
                                className={`text-sm ${
                                  notification.is_read
                                    ? "font-medium text-slate-700"
                                    : "font-bold text-slate-900"
                                }`}
                              >
                                {notification.title}
                              </p>

                              {!notification.is_read && (
                                <span className="mt-1 h-2 w-2 shrink-0 rounded-full bg-blue-600" />
                              )}
                            </div>

                            <p className="mt-1 text-xs leading-5 text-slate-600">
                              {notification.message}
                            </p>

                            <div className="mt-2 flex items-center justify-between gap-2">
                              <p className="text-[11px] text-slate-400">
                                {formatNotificationTime(notification.created_at)}
                              </p>

                              {!notification.is_read && (
                                <button
                                  onClick={() => markAsRead(notification.id)}
                                  className="inline-flex items-center gap-1 rounded-md px-2 py-1 text-[11px] font-medium text-blue-600 hover:bg-blue-100"
                                >
                                  <Check size={13} />
                                  Mark read
                                </button>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Footer */}
                  <div className="border-t border-slate-200 bg-slate-50 px-4 py-3">
                    <button
                      onClick={() => {
                        setNotificationOpen(false);
                        navigate("/customer/notifications");
                      }}
                      className="w-full rounded-lg bg-slate-900 px-4 py-2.5 text-xs font-semibold text-white transition hover:bg-slate-800"
                    >
                      View All Notifications
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Profile dropdown */}
            <div className="relative" ref={profileMenuRef}>
              <button
                type="button"
                onClick={() => setProfileMenuOpen((open) => !open)}
                aria-expanded={profileMenuOpen}
                aria-haspopup="menu"
                className="flex items-center gap-2 rounded-xl p-1.5 text-left transition hover:bg-slate-100 focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-blue-100 text-blue-700">
                  <User size={18} />
                </div>
                <div className="hidden text-right sm:block">
                  <p className="max-w-32 truncate text-sm font-semibold text-slate-800">{user?.username || "Customer"}</p>
                  <p className="text-xs text-slate-500">Customer account</p>
                </div>
                <ChevronDown size={16} className={`text-slate-500 transition ${profileMenuOpen ? "rotate-180" : ""}`} />
              </button>

              {profileMenuOpen && (
                <div role="menu" className="absolute right-0 top-full z-50 mt-2 w-72 overflow-hidden rounded-xl border border-slate-200 bg-white py-2 shadow-xl">
                  <div className="flex items-center gap-3 border-b border-slate-100 px-4 py-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-blue-50 text-blue-700"><CircleUserRound size={22} /></div>
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-slate-800">{user?.username || "Customer"}</p>
                      <p className="text-xs text-slate-500">Customer account</p>
                    </div>
                  </div>
                  <button type="button" role="menuitem" onClick={() => { setProfileMenuOpen(false); navigate("/customer/profile"); }} className="flex w-full items-center gap-3 px-4 py-3 text-left transition hover:bg-slate-50">
                    <CircleUserRound size={18} className="text-slate-500" />
                    <span><span className="block text-sm font-medium text-slate-800">Manage Profile</span><span className="mt-0.5 block text-xs text-slate-500">View or update account details</span></span>
                  </button>

                  <div className="my-1 border-t border-slate-100" />
                  <button type="button" role="menuitem" onClick={() => { setProfileMenuOpen(false); handleLogout(); }} className="flex w-full items-center gap-3 px-4 py-3 text-left text-red-600 transition hover:bg-red-50">
                    <LogOut size={18} /><span className="text-sm font-medium">Logout</span>
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        {/* Breadcrumb */}
        <div className="border-b border-slate-200 bg-white px-4 py-3 sm:px-6">
          <div className="flex items-center gap-2 text-sm text-slate-500">
            <span>
              {platformSettings?.platform?.name || "SEIYALAM"}
            </span>

            <ChevronRight size={15} />

            <span className="font-medium text-slate-800">
              Customer Portal
            </span>

            <span
              className={`ml-auto hidden items-center gap-1.5 text-xs sm:flex ${
                wsConnected ? "text-emerald-600" : "text-slate-400"
              }`}
            >
              <span
                className={`h-2 w-2 rounded-full ${
                  wsConnected ? "bg-emerald-500" : "bg-slate-400"
                }`}
              />
              {wsConnected ? "Live notifications" : "Connecting..."}
            </span>
          </div>
        </div>

        {/* Page */}
        <main className="p-4 sm:p-6">
          <PlatformAnnouncement />
          {children}
        </main>
      </div>

      {/* Shared AI assistant, routed to the customer-only backend by role. */}
      {String(user?.role || "").toUpperCase() === "CUSTOMER" && (
        <AIAssistantWidget />
      )}

      {/* Notification backdrop */}
      {notificationOpen && (
        <div
          className="fixed inset-0 z-20"
          onClick={() => setNotificationOpen(false)}
        />
      )}
    </div>
  );
};

export default CustomerLayout;